<?php 
    mysql_connect('localhost','mapmarki','mapadmin12');  
    mysql_select_db('mapmarki_tss');
?>