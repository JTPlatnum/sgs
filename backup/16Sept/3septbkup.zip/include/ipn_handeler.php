<?php
	$sql = "UPDATE place_order SET status='1', transaction_id='$tran_id', payment_method='$payment_method' where session='$cart_sess'";
	mysql_query($sql);
	
	// Fetch Order details
	$sql_po = "SELECT * from place_order where session = '$cart_sess'";
	$exec_po = mysql_query($sql_po);
	$fetch_po = mysql_fetch_assoc($exec_po);

	// Fetch cart details
	$sql_cart = "SELECT * from cart where session = '$cart_sess'";
	$exec_cart = mysql_query($sql_cart);

	// Email invoice
	require_once(ROOT_DIR."/mpdf/mpdf.php");
	
	$mpdf=new mPDF('win-1252','A4','','',20,15,10,25,10,10); 
	$mpdf->useOnlyCoreFonts = true;    // false is default
	$mpdf->SetProtection(array('print'));
	$mpdf->SetTitle("$site_name - Invoice");
	$mpdf->SetAuthor("$site_name");
	$mpdf->SetWatermarkText("");
	$mpdf->showWatermarkText = true;
	$mpdf->watermark_font = '';
	$mpdf->watermarkTextAlpha = 0.1;
	$mpdf->SetDisplayMode('fullpage');
	
	$html = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>3-1 pdf</title>
	<style type="text/css">
	
	.container{ width:1100px; height:800px; border:0px solid F2F2F2; margin-top:20px;  }
	
	.box{ width:650px; border:0px solid #cccccc; margin-top:30px;  }
	.box1{ width:650px; height:63px; }
	.clear{clear:both;}
	.cart_font_colr {
	margin-left: 10px;
	width: 30px;
	height: 20px;
	float: left;
	border: 1px solid #017ec8;
	}

	
	.product{text-align:left; width: 200px;border-top:1px solid #cccccc;border-right:1px solid #cccccc; padding-left:10px;}
	.product_amount{text-align:right;border-top:1px solid #cccccc; padding-right:10px;}
	.total_text{text-align:right; border-top:1px solid #cccccc;border-right:1px solid #cccccc; font-weight:bold;padding-right:10px;}
	.total{text-align:right; border-top:1px solid #cccccc;font-weight:bold;padding-right:10px;}
	
	</style>
	</head>
	
	<body>
		<img src="'.($fetch_po['status'] == '1' ? ROOT_DIR.'/image/paid.png' : ROOT_DIR.'/image/unpaid.png').'"  alt="logo" style="position:fixed;margin-top:-50px;margin-right:-90px; float:right"/>
	
		<div style="position:fixed; top:50; right:90; text-align:right;">
			'.nl2br($inv_address).'
		</div>
		
		<div align="center">
			 <div class="container">
				<table width="100%" style="border:0px solid blue;">
				  <tr>
					<td style="border:0px solid black;width:200px"><img src="'.ROOT_DIR.'/images/logo.png" height="54" width="150"  alt="logo"></td>
					<td style="border:0px solid red;width:100px"></td>
				  </tr>
				</table>
				
				<div style="width:100%; height:10px;"></div>
				
				<table bgcolor="#f3f3f3" width="650" height="100" cellspacing="2" style="text-align:left;font-size:14px; font-family:Helvetica">
				  <tr>
					<td>
					  <b>Invoice #'.$fetch_po['id'].'</b>
					</td>
				  </tr>
				  <tr>
					<td>
					  Invoice Date: '.date('m/d/Y', $fetch_po['time']).'
					</td>
				  </tr>
				  <tr>
					<td>
					  Due Date: '.date('m/d/Y', $fetch_po['time']).'
					</td>
				  </tr>
				</table>
	  
				<table width="650" style="margin-top:30px; margin-left:-2px; border:0px solid red; text-align:left;font-size:12px; font-family:Helvetica;">
				  <tr>
					<td><b>Invoiced To</b></td>
				  </tr>
				  <tr>
					<td>'.$fetch_po['first_name'].' '.$fetch_po['last_name'].'</td>
				  </tr>
				  <tr>
					<td>'.$fetch_po['address'].'<br />'.$fetch_po['address1'].'</td>
				  </tr>
				  <tr>
					<td>'.$fetch_po['city'].', '.$fetch_po['zip_code'].'</td>
				  </tr>
				  <tr>
					<td>'.$fetch_po['state'].'</td>
				  </tr>
				  <tr>
					<td>'.$fetch_po['country'].'</td>
				  </tr>
				  <tr>
					<td>'.$fetch_po['phone'].'</td>
				  </tr>
				</table>
	 
				<div class="box">
				  <table style="border-collapse:collapse; width:700px; height:400px; line-height:1.6; font-family:Helvetica;font-size:12px;" >
					<tr bgcolor="#efefef">
					  <td width="210" style=" padding-left:10px;text-align:left;border-right:1px solid #cccccc;"> Product </td>
					  <td width="348" style=" padding-left:10px;text-align:left;"> Description </td>
					  <td width="126" style=" padding-right:10px;">Total</td>
					</tr>';
				    while($fetch_cart = mysql_fetch_assoc($exec_cart)){
						if($fetch_cart['fl'] <> '' && $fetch_cart['fl'] <> 0){
							$sql_art = "select thumb from clip_arts where id='".$fetch_cart['fl']."'";
							$exec_art = mysql_query($sql_art);
							$fetch_art = mysql_fetch_assoc($exec_art);
						}
						if($fetch_cart['fr'] <> '' && $fetch_cart['fr'] <> 0){
							$sql_art1 = "select thumb from clip_arts where id='".$fetch_cart['fr']."'";
							$exec_art1 = mysql_query($sql_art1);
							$fetch_art1 = mysql_fetch_assoc($exec_art1);
						}
						if($fetch_cart['bl'] <> '' && $fetch_cart['bl'] <> 0){
							$sql_art2 = "select thumb from clip_arts where id='".$fetch_cart['bl']."'";
							$exec_art2 = mysql_query($sql_art2);
							$fetch_art2 = mysql_fetch_assoc($exec_art2);
						}
						if($fetch_cart['br'] <> '' && $fetch_cart['br'] <> 0){
							$sql_art3 = "select thumb from clip_arts where id='".$fetch_cart['br']."'";
							$exec_art3 = mysql_query($sql_art3);
							$fetch_art3 = mysql_fetch_assoc($exec_art3);
						}
						$bnd_colr = explode(';', $fetch_cart['design_colors']);
						$fnt_colr = explode('_', $fetch_cart['Message_color']);
						
						$sql_bc = "select * from cart_band_colors where rel='".$fetch_cart['uniq']."'";
						$exec_bc = mysql_query($sql_bc);
						$k=0;
						while($fetch_bc = mysql_fetch_assoc($exec_bc)){
							$bnd1 = explode('_', $fetch_bc['band_colors']);
							$bnd_col[$k] = $bnd1[0];
							$k++;
						}
					
					$html .= '<tr>
					  <td class="product">
						'.$fetch_cart['product'].'
					  </td>
					  <td class="product">
					  <div>Band style : '.ucwords($fetch_cart['MStyle']).'</div>
                <div>Style : '.ucwords($fetch_cart['Style']).'</div>
                <div>Front Message : '.($fetch_art['thumb'] <> '' ? '<img style="width:48px; height:30px;" src="thumb/'.$fetch_art['thumb'].'" >' : '').$fetch_cart['Front_message'].($fetch_art1['thumb'] <> '' ? '<img style="width:48px; height:30px;" src="thumb/'.$fetch_art1['thumb'].'" >' : '').'</div>
                <div>Back Message : '.($fetch_art2['thumb'] <> '' ? '<img style="width:48px; height:30px;" src="thumb/'.$fetch_art2['thumb'].'" > ':'').$fetch_cart['Back_message'].($fetch_art3['thumb'] <> '' ? '<img style="width:48px; height:30px;" src="thumb/'.$fetch_art3['thumb'].'" >' : '').'</div>
               <!-- <div>Inside Message : '.$fetch['Inside_message'].'</div>-->
                <div>Font: '.$fetch_cart['font_type'].'</div>
                <div><div style="float:left">Font Color:</div>
				<table><tr><td class="cart_font_colr" title="" style="background-color:'.$fetch_cart['text_colors'].'"></td></tr></table>
				</div><div class="clear"></div>
				<div><div style="float:left">-Band Color: </div>
				
				<table>
				<tr>
				';
				$k1=0; 
				foreach($bnd_colr as $k => $v){
					$html .= '<td class="cart_font_colr" title="" style="background-color:'.$v.'"></td>';
					$k1++; }
					$html .= '</tr></table>
				</div>
                <div>Extra-Small : '.$fetch_cart['ex_small'].'</div>
                <div>Small : '.$fetch_cart['small'].'</div>
                <div>Medium : '.$fetch_cart['medium'].'</div>
                <div>Large : '.$fetch_cart['large'].'</div>
                <div>Extra-Large : '.$fetch_cart['ex_large'].'</div>
                <div>Individually Bagged : '.($fetch_cart['ind_bag'] == 1 ? "Yes" : "No").'</div>
                <div>Glitter Filled : '.($fetch_cart['glitt_fil'] == 1 ? "Yes" : "No").'</div>
                <div>Rush Production :  '.($fetch_cart['rush_prod'] == 1 ? "Yes" : "No").'</div>
                <div>Special Instructions : '.$fetch_cart['Special_instructions'].'</div>
				</td>
					  <td class="product_amount">$'.$fetch_cart['price'].'</td>
					</tr>
					';
					}
					$html .= '<tr bgcolor="#efefef">
					  <td class="total_text"></td>
					  <td class="total_text">Sub Total</td>
					  <td class="total">$'.$fetch_po['totalamount'].'</td>
					</tr>
					<tr bgcolor="#efefef">
					  <td class="total_text"></td>
					  <td class="total_text">Discount</td>
					  <td class="total">$0</td>
					</tr>
					<tr bgcolor="#efefef">
					  <td class="total_text"></td>
					  <td class="total_text">Tax</td>
					  <td class="total">$0</td>
					</tr>
					<tr bgcolor="#efefef">
					  <td class="total_text"></td>
					  <td class="total_text">Total</td>
					  <td class="total">$'.$fetch_po['totalamount'].'</td>
					</tr>
				  </table>
				</div>
				
				<p style="font-size:16px; text-align:left; margin-top:30px; font-family:Helvetica;">Transactions</p>
	 
				<div class="box1">
				  <table width="700" border="0" style="border-collapse:collapse; font-family:Helvetica; border:1px  solid #cccccc;font-size:12px;" cellpadding="5">
					<tr bgcolor="#F2F2F2">
					  <td> Transaction Date</td>
					  <td>Gateway</td>
					  <td style=" width:192px;"> Transaction ID </td>
					  <td class="product_amount"> Amount</td>
					</tr>
					'.($fetch_po['status'] == '1' ?
					'<tr bgcolor="#F2F2F2">
					  <td> '.date('m/d/Y', $fetch_po['time']).'</td>
					  <td> '.$fetch_po['type'].'</td>
					  <td style=" width:192px;"> '.$fetch_po['transaction_id'].' </td>
					  <td class="product_amount"> $'.$fetch_po['totalamount'].'</td>
					</tr>' : '').
					'<tr bgcolor="#efefef">
					  <td style="border-right:0px;"></td >
					  <td style="border-left:0px; border-right:0px;" ></td>
					  <td style=" text-align:right; border-left:0px;"> Balance </td>
					  <td class="product_amount">$'.($fetch_po['status'] == '1' ? 0.00 : $fetch_po['totalamount']).' </td>
					</tr>
				  </table>
				</div>
			</div>
		</div>
	</body>
	</html>';
	$mpdf->WriteHTML($html);

	$content = $mpdf->Output('', 'S');
	
	$content = chunk_split(base64_encode($content));
	$uid = md5(uniqid(time())); 
	$subject = $site_name.' Invoice';
	
	$message_c = 'Hello '.$fetch_po['first_name'].' '.$fetch_po['last_name'].',

Thank you for your purchase with FirstClassWristbands.com. Your order ID Number is '.$fetch_po['id'].'.

Be sure to like us on Facebook to receive updates and information about upcoming sales and promotions. https://www.facebook.com/FirstClassWristbands

Should you have any questions feel free to contact us at 1(800)468-9010.

We appreciate your business,

FirstClassWristbands.com';
	$filename = 'FCW'.$fetch_po['id'].'.pdf';
	
	// save file
	$path = ROOT_DIR.'/invoices/'.$filename;
	$mpdf->Output($path,'F');
	
	//$mpdf->Output();
	
	//exit;
	
	$header = "From: ".$site_name." <".$email_def.">\r\n";
	$header .= "Reply-To: ".$email_def."\r\n";
	$header .= "MIME-Version: 1.0\r\n";
	$header .= "Content-Type: multipart/mixed; boundary=\"".$uid."\"\r\n\r\n";
	$header .= "This is a multi-part message in MIME format.\r\n";
	$header .= "--".$uid."\r\n";
	$header .= "Content-type:text/plain; charset=iso-8859-1\r\n";
	$header .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
	$header .= $message_c."\r\n\r\n";
	$header .= "--".$uid."\r\n";
	$header .= "Content-Type: application/pdf; name=\"".$filename."\"\r\n";
	$header .= "Content-Transfer-Encoding: base64\r\n";
	$header .= "Content-Disposition: attachment; filename=\"".$filename."\"\r\n\r\n";
	$header .= $content."\r\n\r\n";
	$header .= "--".$uid."--";
	
	$is_sent = mail($fetch_po['email'], $subject, "", $header);
	$is_sent = mail($email_def, 'New order placed - '.$subject, "", $header);

?>