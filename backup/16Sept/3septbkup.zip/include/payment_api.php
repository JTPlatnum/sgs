<?php

$tabl = "place_order";

$sql_ck = "select * from $tabl where session='".$cart_sess."'";
$exec_ck = mysql_query($sql_ck);
$num_ck = mysql_num_rows($exec_ck);
$fetch_ck = mysql_fetch_assoc($exec_ck);
		
$dvar['company_name'] = $fetch_ck['company_name'];
$dvar['first_name'] = $fetch_ck['first_name'];
$dvar['last_name'] = $fetch_ck['last_name'];
$dvar['address'] = $fetch_ck['address'];
$dvar['address1'] = $fetch_ck['address1'];
$dvar['city'] = $fetch_ck['city'];
$dvar['state'] = $fetch_ck['state'];
$dvar['zip_code'] = $fetch_ck['zip_code'];
$dvar['country'] = $fetch_ck['country'];
$dvar['phone'] = $fetch_ck['phone'];
$dvar['fax'] = $fetch_ck['fax'];
$dvar['email'] = $fetch_ck['email'];
$dvar['shipping_company'] = $fetch_ck['shipping_company'];
$dvar['shipping_first_name'] = $fetch_ck['shipping_first_name'];
$dvar['shipping_last_name'] = $fetch_ck['shipping_last_name'];
$dvar['shipping_address'] = $fetch_ck['shipping_address'];
$dvar['shipping_address1'] = $fetch_ck['shipping_address1'];
$dvar['shipping_city'] = $fetch_ck['shipping_city'];
$dvar['shipping_state'] = $fetch_ck['shipping_state'];
$dvar['shipping_zip'] = $fetch_ck['shipping_zip'];
$dvar['shipping_country'] = $fetch_ck['shipping_country'];
$dvar['shipping_phone'] = $fetch_ck['shipping_phone'];

// If step1 form is posted, check for errors
if (!empty($_POST['DO_STEP_1'])) {
		$dvar['company_name'] = $_POST['billing-address-company'];
		$dvar['first_name'] = $_POST['billing-address-first-name'];
		$dvar['last_name'] = $_POST['billing-address-last-name'];
		$dvar['address'] = $_POST['billing-address-address1'];
		$dvar['address1'] = $_POST['billing-address-address2'];
		$dvar['city'] = $_POST['billing-address-city'];
		$dvar['state'] = $_POST['billing-address-state'];
		$dvar['zip_code'] = $_POST['billing-address-zip'];
		$dvar['country'] = $_POST['shipping-address-country'];
		$dvar['phone'] = $_POST['billing-address-phone'];
		$dvar['fax'] = $_POST['billing-address-fax'];
		$dvar['email'] = $_POST['billing-address-email'];
		$payment_method_form = $_POST['payment_method_form'];
		
		$dvar['shipping_company'] = $_POST['shipping-address-company'];
		$dvar['shipping_first_name'] = $_POST['shipping-address-first-name'];
		$dvar['shipping_last_name'] = $_POST['shipping-address-last-name'];
		$dvar['shipping_address'] = $_POST['shipping-address-address1'];
		$dvar['shipping_address1'] = $_POST['shipping-address-address2'];
		$dvar['shipping_city'] = $_POST['shipping-address-city'];
		$dvar['shipping_state'] = $_POST['shipping-address-state'];
		$dvar['shipping_zip'] = $_POST['shipping-address-zip'];
		$dvar['shipping_country'] = $_POST['shipping-address-country'];
		$dvar['shipping_phone'] = $_POST['shipping-address-phone'];

		if($dvar['first_name'] == ""){
			$flag[26] = "r";
		}
		if($dvar['first_name'] == ""){
			$flag[27] = "r";
		}
		else if($dvar['address'] == ""){
			$flag[28] = "r";
		}
		else if($dvar['city'] == ""){
			$flag[29] = "r";
		}
		else if($dvar['state'] == ""){
			$flag[30] = "r";
		}
		else if($dvar['zip_code'] == ""){
			$flag[46] = "r";
		}
		/*else if($dvar['country'] == ""){
			$flag[31] = "r";
		}*/
		else if($dvar['phone'] == ""){
			$flag[32] = "r";
		}
		else if($dvar['email'] == ""){
			$flag[8] = "r";
		}
		else if(!preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $dvar['email'])){$flag[9] = "r";}
		if(!empty($flag)){
			$flag_r = 'r';
		}
		else{ 
			
			if($num_ck == 0){
				$column = "uniq";
				$length = "8";
				$uniq = rg($tabl, $column, $length);
				$add_dvar = array('uniq' => $uniq, 'session' => $cart_sess, 'status' => '0', 'time' => time());
	//			$remove_dvar = array('totalamount');
	//			$change_dvar = array('status' => '1');
	
				list($insert_q[0], $insert_q[1]) = insert_query($dvar, $add_dvar, $remove_dvar, $change_dvar);
				$sql = "INSERT into $tabl(sort, $insert_q[0]) SELECT max(sort)+1, $insert_q[1] from $tabl";
			}
			else{

			$add_dvar = array('status' => '0', 'time' => time());
//			$remove_dvar = array('totalamount');
//			$change_dvar = array('status' => '0');
			
			$sql = "UPDATE $tabl SET ".update_query($dvar, $add_dvar, $remove_dvar, $change_dvar)." where session='".$cart_sess."'";
			} //echo $sql;
			if(mysql_query($sql)){//echo "vsdfn";
				$flag['g'] = '11115'; //echo $sql;
			}
			else{
				$flag['q'] = "r";
				// $flag['g'] = '219';
			}
  }
  echo print_messages($flag, $error_message, $success_message);

}
  
// If there is no POST data or a token-id, print the initial shopping cart form to get ready for Step One.
if ((empty($_POST['DO_STEP_1']) && empty($_GET['token-id'])) || (!empty($_POST['DO_STEP_1']) && $flag['g'] == '')) {

    print '

      <h3> Customer Information</h3><br>
      <h4> Billing Details</h4><br>

        <form action="'.$_SERVER['PHP_SELF'].'" method="post">
          <table class="checkout">
          <tr>
			  <td style="width:150px" class="dev_inputtxt1">First Name </td><td style="width:250px"><input tabindex="1" class="dev_inputtxt" type="text" name="billing-address-first-name" id="billing-address-first-name" value="'.$dvar['first_name'].'"></td>
			  <td style="width:150px" class="dev_inputtxt1">Address </td><td style="width:250px"><input tabindex="7" class="dev_inputtxt" type="text" name="billing-address-address1" id="billing-address-address1" value="'.$dvar['address'].'"></td>
		  </tr>
          <tr>
		  	<td style="width:150px" class="dev_inputtxt1">Last Name </td><td style="width:250px"><input tabindex="2" class="dev_inputtxt" type="text" name="billing-address-last-name" id="billing-address-last-name" value="'.$dvar['last_name'].'"></td>
          	<td style="width:150px" class="dev_inputtxt1">Address 2 </td><td style="width:250px"><input tabindex="8" class="dev_inputtxt" type="text" name="billing-address-address2" id="billing-address-address2" value="'.$dvar['address1'].'"></td>
		</tr>
        <tr>
		  	<td style="width:150px" class="dev_inputtxt1">Company</td><td style="width:250px"><input tabindex="3" class="dev_inputtxt" type="text" name="billing-address-company" id="billing-address-company" value="'.$dvar['company_name'].'"></td>
            <td style="width:150px" class="dev_inputtxt1">City </td><td style="width:250px"><input tabindex="9" class="dev_inputtxt" type="text" name="billing-address-city" id="billing-address-city" value="'.$dvar['city'].'"></td>
		</tr>
        <tr>
          	<td style="width:150px" class="dev_inputtxt1">Phone Number </td><td style="width:250px"><input tabindex="4" class="dev_inputtxt" type="text" name="billing-address-phone" id="billing-address-phone" value="'.$dvar['phone'].'"></td>
			<td style="width:150px" class="dev_inputtxt1">State/Province </td><td style="width:250px"><input tabindex="10" class="dev_inputtxt" type="text" name="billing-address-state" id="billing-address-state" value="'.$dvar['state'].'"></td>
		</tr>
          <tr>
			<td style="width:150px" class="dev_inputtxt1">Fax Number </td><td style="width:250px"><input tabindex="5" class="dev_inputtxt" type="text" name="billing-address-fax"  id="billing-address-fax" value="'.$dvar['fax'].'"></td>
            <td style="width:150px" class="dev_inputtxt1">Zip/Postal </td><td style="width:250px"><input tabindex="11" class="dev_inputtxt" type="text" name="billing-address-zip" id="billing-address-zip" value="'.$dvar['zip_code'].'"></td>

		</tr>
        <tr>
            <td style="width:150px" class="dev_inputtxt1">Email Address </td><td style="width:250px"><input tabindex="6" class="dev_inputtxt" type="text" name="billing-address-email" id="billing-address-email" value="'.$dvar['email'].'" ></td>
		  	<td style="width:150px" class="dev_inputtxt1">Country </td>
		  <td style="width:250px">
		  	<select name="billing-address-country" id="billing-address-country" class="dev_select_country" tabindex="12">
				<option value="">Select Country</option>'; ?>
				<?php while($fetch_c = mysql_fetch_assoc($exec_c)){ ?>
				<option value="<?php echo $fetch_c['short_form']; ?>" <?php if($dvar['country'] == $fetch_c['short_form'] || ($dvar['country'] == '' && $fetch_c['short_form'] == 'US')){ echo 'selected';} ?>><?php echo $fetch_c['country_name']; ?></option>
				<?php } ?>
			<?php echo '</select>
		  	</td>
		</tr>
          <tr><td colspan="4" style="width:150px"><h4><br /> Shipping Details</h4><br>
		  <input type="checkbox" name="dupe" id="dupe" value=""> Use same shipping address as billing address<br>
		  </td></tr>
		  
          <tr>
		  	<td style="width:150px" class="dev_inputtxt1">First Name </td><td style="width:250px"><input tabindex="13" class="dev_inputtxt" type="text" name="shipping-address-first-name" id="shipping-address-first-name" value="'.$dvar['shipping_first_name'].'"></td>
		  	<td style="width:150px" class="dev_inputtxt1">Address </td><td style="width:250px"><input tabindex="18" class="dev_inputtxt" type="text" name="shipping-address-address1" id="shipping-address-address1" value="'.$dvar['shipping_address'].'"></td>
		 </tr>
          <tr>
            <td style="width:150px" class="dev_inputtxt1">Last Name </td><td style="width:250px"><input tabindex="14" class="dev_inputtxt" type="text" name="shipping-address-last-name" id="shipping-address-last-name" value="'.$dvar['shipping_last_name'].'"></td>
            <td style="width:150px" class="dev_inputtxt1">Address 2</td><td style="width:250px"><input tabindex="19" class="dev_inputtxt" type="text" name="shipping-address-address2" id="shipping-address-address2" value="'.$dvar['shipping_address1'].'"></td>
		 </tr>
         <tr>
            <td style="width:150px" class="dev_inputtxt1">Company</td><td style="width:250px"><input tabindex="15" class="dev_inputtxt" id="shipping-address-company" type="text" name="shipping-address-company" value="'.$dvar['shipping_company'].'"></td>
		 	<td style="width:150px" class="dev_inputtxt1">City </td><td style="width:250px"><input tabindex="20" class="dev_inputtxt" type="text" name="shipping-address-city" id="shipping-address-city" value="'.$dvar['shipping_city'].'"></td></tr>
          <tr>
          <td style="width:150px" class="dev_inputtxt1">Phone Number </td><td style="width:250px"><input tabindex="16" class="dev_inputtxt" type="text" name="shipping-address-phone" id="shipping-address-phone" value="'.$dvar['shipping_phone'].'"></td>
		  	<td style="width:150px" class="dev_inputtxt1">State/Province </td><td style="width:250px"><input tabindex="21" class="dev_inputtxt" type="text" name="shipping-address-state" id="shipping-address-state" value="'.$dvar['shipping_state'].'"></td>
	     </tr>
          <tr>
            <td style="width:150px" class="dev_inputtxt1">Zip/Postal </td><td style="width:250px"><input tabindex="17" class="dev_inputtxt" type="text" name="shipping-address-zip" id="shipping-address-zip" value="'.$dvar['shipping_zip'].'"></td>
		  <td style="width:150px" class="dev_inputtxt1">Country</td>
		  	<td style="width:250px">
		  		<select name="shipping-address-country"  id="shipping-address-country" class="dev_select_country" tabindex="22">
					<option value="">Select Country</option>'; ?>
					<?php while($fetch_c = mysql_fetch_assoc($exec_c1)){ ?>
					<option value="<?php echo $fetch_c['short_form']; ?>" <?php if($dvar['shipping_country'] == $fetch_c['short_form'] || ($dvar['shipping_country'] == '' && $fetch_c['short_form'] == 'US')){ echo 'selected';} ?>><?php echo $fetch_c['country_name']; ?></option>
					<?php } ?>
            	<?php echo '</select>
			</td>
			</tr>
          <tr>
            <td style="width:150px" class="dev_inputtxt1">Payment Method</td><td style="width:250px">
			<div style="margin-top:15px; font-family: Open Sans, sans-serif;">
			<input name="payment_method_form" value="paypal" type="radio"> <img src="images/paypal.png" style="vertical-align: middle; width:40px;"> Paypal <br />
			<input name="payment_method_form" value="merchantone" type="radio"> <img src="images/card.png" style="vertical-align: middle; width:40px; margin-top: 5px;"> Credit/Debit Card
			</div>
			</td>
		  <td style="width:150px" class="dev_inputtxt1"></td><td style="width:250px">
		  <div class="dev_chkout_price">
          <h3>Your Total $'.$dvar['totalamount'].'</h3>
		  </td>
			</tr>
			
          <tr><td colspan="4" align=center><input tabindex="23" class="dev_submitbtn" type="submit" value="Next step" name="nxtbtn"><input class="dev_inputtxt" type="hidden" name ="DO_STEP_1" value="true"></td></tr>
          </table>

        </form>

    ';
}
else if(!empty($_POST['DO_STEP_1'])){
	if($flag['g'] <> ''){
		if($payment_method_form == 'paypal'){
			require_once('paypal-1.3.0/paypal.class.php');  // include the class file
				$p = new paypal_class;             // initiate an instance of the class
				if($sandbox_env == '1'){
				  $p->paypal_url = 'https://www.sandbox.paypal.com/cgi-bin/webscr';   // testing paypal url
				}
				else{
				  $p->paypal_url = 'https://www.paypal.com/cgi-bin/webscr';     // paypal url
				}
						  
				// setup a variable for this script (ie: 'http://www.micahcarrick.com/paypal.php')
				$this_script = $_SERVER['REQUEST_URI'];
				$p->add_field('business', $email_merchant);
				$p->add_field('return', ROOT_URL);
				$p->add_field('cancel_return', 'http://'.$_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"] .'?action=cancel');
				$p->add_field('notify_url', ROOT_URL."/ipn.php?cart=".$cart_sess);
				$p->add_field('item_name', ' Order');
				$p->add_field('amount', $dvar['totalamount']);
				$p->add_field('page_style', '');
				echo '<div class="paypal">';
				 $p->submit_paypal_post(); // submit the fields to paypal
				 echo '</div>';
		}
		else{
			echo print_merchantone_form($cart_sess, $gatewayURL, $APIKey, $dvar['totalamount']);
		}

	}

} elseif (!empty($_GET['token-id'])) {

    // Step Three: Once the browser has been redirected, we can obtain the token-id and complete
    // the transaction through another XML HTTPS POST including the token-id which abstracts the
    // sensitive payment information that was previously collected by the Payment Gateway.
    $tokenId = $_GET['token-id'];
    $xmlRequest = new DOMDocument('1.0','UTF-8');
    $xmlRequest->formatOutput = true;
    $xmlCompleteTransaction = $xmlRequest->createElement('complete-action');
    appendXmlNode($xmlCompleteTransaction,'api-key',$APIKey);
    appendXmlNode($xmlCompleteTransaction,'token-id',$tokenId);
    $xmlRequest->appendChild($xmlCompleteTransaction);


    // Process Step Three
    $data = sendXMLviaCurl($xmlRequest,$gatewayURL);


    $gwResponse = @new SimpleXMLElement((string)$data);

//    print "        <p><h2>Step Three: Script automatically completes the transaction <br /></h2></p>";

    if ((string)$gwResponse->result == 1 ) {
        print " <p><h3> Transaction was Approved. <br />
		We are processing your order now.</h3></p>\n";
		$tran_id = (string)$gwResponse->transaction-id;
		$payment_method = 'merchantone';
		// Required by ipn handeler
		/*
		$tran_id 		-> Transaction id
		$cart_sess 		-> cart session
		$payment_method -> Payment method; paypal, merchant one etc
		*/
		require_once("include/ipn_handeler.php");
		echo '<meta http-equiv="refresh" content="0; URL=thank_you_order.php">'; //?order_id='.$fetch_po['id'].'

    } elseif((string)$gwResponse->result == 2)  {
        print " <p><h3> Transaction was Declined.</h3>\n";
        print " Decline Description : " . (string)$gwResponse->{'result-text'} ." </p><br /><br />";
       // print " <p><h3>XML response was:</h3></p>\n";
        //print '<pre>' . (htmlentities($data)) . '</pre>';
		echo print_merchantone_form($cart_sess, $gatewayURL, $APIKey, $dvar['totalamount']);
    } else {
        print " <p><h3> Transaction caused an Error.</h3>\n";
        print " Error Description: " . (string)$gwResponse->{'result-text'} ." </p><br /><br />";
//        print " <p><h3>XML response was:</h3></p>\n";
//        print '<pre>' . (htmlentities($data)) . '</pre>';
		echo print_merchantone_form($cart_sess, $gatewayURL, $APIKey, $dvar['totalamount']);
    }



} else {
  print "ERROR IN SCRIPT<BR>";
}


?>