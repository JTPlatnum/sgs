<?php
mysql_connect("localhost", "root", "sunny007") or die ("Oops! Server not connected"); // connect to the host
mysql_select_db("veenomous") or die ("Oops! DB not connected"); // select the database
?>