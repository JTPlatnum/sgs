<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="thickbox/thickbox.css" type="text/css" media="screen" />

<script type="text/javascript" src="scripts/jquery-latest.pack.js"></script>
<script type="text/javascript" src="thickbox/thickbox-compressed.js"></script>
<script type="text/javascript" src="../ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="js/clock.js"></script>
<script type="text/javascript" src="js/validate_functions.js"></script>
<script type="text/javascript" src="js/common.js"></script>

<script type="text/javascript" src="fancybox/jquery.mousewheel-3.0.4.pack.js"></script>
<script type="text/javascript" src="fancybox/jquery.fancybox-1.3.4.pack.js"></script>
<link rel="stylesheet" type="text/css" href="fancybox/jquery.fancybox-1.3.4.css" media="screen" />

<link rel="stylesheet" type="text/css" href="css/dhtmlxcalendar.css"></link>
<link rel="stylesheet" type="text/css" href="css/dhtmlxcalendar_dhx_skyblue.css"></link>
<!--<link rel="stylesheet" type="text/css" href="css/project.css"></link>-->
<script src="js/dhtmlxcalendar.js"></script>
<script>
  var myCalendar;
  $( document ).ready(function() {
	  myCalendar = new dhtmlXCalendarObject(["calendar","calendar2","calendar3"]);	
	});
</script>
