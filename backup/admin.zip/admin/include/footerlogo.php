<div class="main">
        <div class="image_0"><a href="http://suffescom.com/" target="_blank"><img src="images/logo.gif" alt="images/logo_text" width="182" height="40" /></a></div>
</div>