<div style="position: fixed; bottom: 0; right: 0; padding: 5px; background-color: white;">
    <div id="google_translate_element"></div><script type="text/javascript">
    function googleTranslateElementInit() {
      new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
    }
    </script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
</div>


<div class="footer">
        <div class="sub_container">
          <div class="footer_main">
            <ul class="footer_menu">
              <li style="margin-left:0px"> <a href="index.php"> Home </a> </li>
              <li> <a href="testimonials.php">Real Stories </a> </li>
              <li> <a href="science.php"> Science </a> </li>
              <li> <a href="faq_nutricap.php"> Faq </a></li>
              <li> <a href="ingredients_nutricap.php"> Ingredients </a></li>
              <li> <a href="sitemap.php"> Site Map </a></li>
              <li> <a href="product_detail.php?id=10"> Order Now </a></li>
              <li> <a href="contactus.php"> Contact Us</a></li>
              <li> <a href="privacypolicy.php"> Privacy Policy </a></li>
              <li> <a href="terms.php"> Autoship Terms and Conditions </a></li>
            </ul>
            <div class="clear"></div>
            <div class="footnote"> &copy;2012 <?php echo $site_name; ?>. All Rights Reserved. </div>
            <div class="clear"></div>
          </div>
        </div>
      </div>